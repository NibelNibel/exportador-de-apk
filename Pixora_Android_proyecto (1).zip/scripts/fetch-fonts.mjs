/* Descarga las fuentes de Google Fonts que usa www/index.html y las guarda en
 * www/fonts/ para que la app funcione SIN conexión.
 *
 * - Se ejecuta en GitHub Actions (ahí sí hay Internet) antes de sincronizar con Android.
 * - Si algo falla, NO toca index.html: la app seguirá cargando las fuentes desde
 *   Internet cuando haya conexión (comportamiento original).
 * - Si todo va bien, elimina de index.html los enlaces a Google Fonts y deja solo
 *   la hoja local fonts/fonts.css.
 *
 * Uso: node scripts/fetch-fonts.mjs
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';

const root = process.cwd();
const indexPath = path.join(root, 'www', 'index.html');
const fontsDir = path.join(root, 'www', 'fonts');
const UA =
  'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36';

async function get(url, asText) {
  let lastErr;
  for (let i = 1; i <= 3; i++) {
    try {
      const r = await fetch(url, { headers: { 'User-Agent': UA }, signal: AbortSignal.timeout(30000) });
      if (!r.ok) throw new Error('HTTP ' + r.status + ' en ' + url);
      return asText ? await r.text() : Buffer.from(await r.arrayBuffer());
    } catch (e) {
      lastErr = e;
      await new Promise((res) => setTimeout(res, 1000 * i));
    }
  }
  throw lastErr;
}

async function pool(items, limit, worker) {
  const queue = items.slice();
  await Promise.all(
    Array.from({ length: Math.min(limit, queue.length) }, async () => {
      while (queue.length) await worker(queue.shift());
    })
  );
}

const html = await fs.readFile(indexPath, 'utf8');
const cssUrls = [
  ...new Set(
    [...html.matchAll(/https:\/\/fonts\.googleapis\.com\/css2\?[^"'<>\s]+/g)].map((m) => m[0].replace(/&amp;/g, '&'))
  )
];

if (!cssUrls.length) {
  console.log('No hay enlaces a Google Fonts en www/index.html. Nada que hacer.');
  process.exit(0);
}

console.log('Hojas de fuentes encontradas:', cssUrls.length);

let allCss = '';
const fontUrls = new Set();
for (const u of cssUrls) {
  const css = await get(u, true);
  if (!css.includes('@font-face')) throw new Error('Respuesta inesperada de Google Fonts para ' + u);
  allCss += css + '\n';
  for (const m of css.matchAll(/url\((https:\/\/fonts\.gstatic\.com\/[^)]+)\)/g)) fontUrls.add(m[1]);
}

console.log('Archivos de fuente a descargar:', fontUrls.size);
await fs.rm(fontsDir, { recursive: true, force: true });
await fs.mkdir(fontsDir, { recursive: true });

const names = new Map();
let done = 0;
await pool([...fontUrls], 6, async (url) => {
  const ext = (url.match(/\.(woff2|woff|ttf|otf)(?:$|\?)/) || [, 'woff2'])[1];
  const name = crypto.createHash('sha1').update(url).digest('hex').slice(0, 14) + '.' + ext;
  await fs.writeFile(path.join(fontsDir, name), await get(url, false));
  names.set(url, name);
  done++;
});

for (const [url, name] of names) allCss = allCss.split(url).join(name);
await fs.writeFile(path.join(fontsDir, 'fonts.css'), allCss);

/* Todo bien: quitar los enlaces remotos del index.html de esta compilación. */
let out = html
  .replace(/<link rel="preconnect" href="https:\/\/fonts\.googleapis\.com">/g, '')
  .replace(/<link rel="preconnect" href="https:\/\/fonts\.gstatic\.com" crossorigin>/g, '')
  .replace(/<link href="https:\/\/fonts\.googleapis\.com\/css2\?[^"]*" rel="stylesheet">/g, '');
await fs.writeFile(indexPath, out);

console.log('Fuentes locales listas (' + done + ' archivos). index.html ya no depende de Internet para las fuentes.');
