/* Ajustes sobre el proyecto Android que genera "npx cap add android".
 * Es idempotente: se puede ejecutar varias veces sin duplicar cambios.
 *
 *  - Orientación vertical (la interfaz de Pixora pide el móvil en vertical)
 *  - Teclado virtual: adjustResize
 *  - Permisos de almacenamiento solo para Android 9 o inferior
 *  - Iconos y pantalla de inicio de Pixora
 *  - versionCode / versionName
 *  - Memoria de Gradle
 *
 * Uso: node scripts/patch-android.mjs
 */
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const androidDir = path.join(root, 'android');
const resDir = path.join(androidDir, 'app', 'src', 'main', 'res');
const manifestPath = path.join(androidDir, 'app', 'src', 'main', 'AndroidManifest.xml');
const gradlePath = path.join(androidDir, 'app', 'build.gradle');

function fail(msg) {
  console.error('ERROR: ' + msg);
  process.exit(1);
}
if (!fs.existsSync(androidDir)) fail('No existe la carpeta android/. Ejecuta antes: npx cap add android');
if (!fs.existsSync(manifestPath)) fail('No se encuentra ' + manifestPath);

/* ---------- 1. AndroidManifest.xml ---------- */
let m = fs.readFileSync(manifestPath, 'utf8');

m = m.replace(/<activity\b([^>]*)>/, (full, attrs) => {
  const setAttr = (name, value) => {
    const re = new RegExp('\\s*android:' + name + '="[^"]*"');
    attrs = re.test(attrs)
      ? attrs.replace(re, '\n            android:' + name + '="' + value + '"')
      : attrs.replace(/\s*$/, '') + '\n            android:' + name + '="' + value + '"';
  };
  setAttr('screenOrientation', 'portrait');
  setAttr('windowSoftInputMode', 'adjustResize');
  return '<activity' + attrs + '>';
});

const addPerm = (name, xml) => {
  if (!m.includes(name)) m = m.replace('</manifest>', '    ' + xml + '\n</manifest>');
};
addPerm('android.permission.INTERNET', '<uses-permission android:name="android.permission.INTERNET" />');
addPerm(
  'android.permission.WRITE_EXTERNAL_STORAGE',
  '<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />'
);

fs.writeFileSync(manifestPath, m);
console.log('OK  AndroidManifest.xml (vertical, adjustResize, permisos)');

/* ---------- 2. Iconos y pantalla de inicio ---------- */
const srcRes = path.join(root, 'resources', 'android', 'res');
if (fs.existsSync(srcRes)) {
  fs.cpSync(srcRes, resDir, { recursive: true, force: true });
  console.log('OK  Iconos copiados a ' + path.relative(root, resDir));
} else {
  console.warn('AVISO: no existe resources/android/res; se quedan los iconos por defecto de Capacitor');
}

const splashPort = path.join(root, 'resources', 'android', 'splash', 'splash_port.png');
const splashLand = path.join(root, 'resources', 'android', 'splash', 'splash_land.png');
let splashCount = 0;
function walk(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) {
      walk(p);
    } else if (e.name === 'splash.png') {
      const src = /land/i.test(path.basename(path.dirname(p))) ? splashLand : splashPort;
      if (fs.existsSync(src)) {
        fs.copyFileSync(src, p);
        splashCount++;
      }
    }
  }
}
if (fs.existsSync(resDir)) walk(resDir);
console.log('OK  Pantalla de inicio reemplazada en ' + splashCount + ' archivo(s)');

/* ---------- 3. Versión ---------- */
if (fs.existsSync(gradlePath)) {
  const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
  const code = parseInt(process.env.GITHUB_RUN_NUMBER || '1', 10) || 1;
  let g = fs.readFileSync(gradlePath, 'utf8');
  const before = g;
  g = g.replace(/(versionCode\s*=?\s*)\d+/, '$1' + code);
  g = g.replace(/(versionName\s*=?\s*)"[^"]*"/, '$1"' + pkg.version + '"');
  if (g === before) console.warn('AVISO: no se encontró versionCode/versionName en build.gradle (sin cambios)');
  else fs.writeFileSync(gradlePath, g);
  console.log('OK  versionName ' + pkg.version + ' · versionCode ' + code);
}

/* ---------- 4. Memoria de Gradle ---------- */
const gpPath = path.join(androidDir, 'gradle.properties');
if (fs.existsSync(gpPath)) {
  let gp = fs.readFileSync(gpPath, 'utf8');
  const line = 'org.gradle.jvmargs=-Xmx3g -Dfile.encoding=UTF-8';
  gp = /^org\.gradle\.jvmargs=.*$/m.test(gp) ? gp.replace(/^org\.gradle\.jvmargs=.*$/m, line) : gp + '\n' + line + '\n';
  fs.writeFileSync(gpPath, gp);
  console.log('OK  gradle.properties');
}

console.log('Parcheo de Android terminado.');
