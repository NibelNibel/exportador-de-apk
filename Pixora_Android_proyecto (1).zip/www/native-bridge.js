/* Pixora · puente nativo (Capacitor / Android)
 *
 * Solo actúa dentro de la app Android. En un navegador normal no hace nada,
 * así que la versión web sigue funcionando exactamente igual.
 *
 * Qué resuelve (el WebView de Android no soporta estas APIs web):
 *   1. Descargas con <a download> sobre blobs  -> se guardan en Documentos/Pixora
 *   2. navigator.share({files})                -> hoja nativa de compartir
 *   3. Barra de estado con iconos claros (la interfaz es oscura)
 */
(function () {
  'use strict';

  var cap = window.Capacitor;
  var isNative = !!(cap && typeof cap.isNativePlatform === 'function' && cap.isNativePlatform());
  var N = (window.PixoraNative = { isNative: isNative });
  if (!isNative) return;

  var FOLDER = 'Pixora';

  function plugin(name) {
    try { return cap.Plugins && cap.Plugins[name]; } catch (e) { return null; }
  }

  function toast(msg) {
    try {
      var t = document.getElementById('toast');
      if (!t) return;
      t.textContent = msg;
      t.classList.add('show');
      clearTimeout(toast._t);
      toast._t = setTimeout(function () { t.classList.remove('show'); }, 2600);
    } catch (e) {}
  }

  function blobToBase64(blob) {
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onload = function () {
        var s = String(r.result || '');
        resolve(s.slice(s.indexOf(',') + 1));
      };
      r.onerror = function () { reject(r.error || new Error('No se pudo leer el archivo')); };
      r.readAsDataURL(blob);
    });
  }

  function cleanName(n) {
    return String(n || 'pixora').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').slice(0, 120) || 'pixora';
  }

  /* Escribe un blob en el almacenamiento de la app (caché) y devuelve su URI. */
  async function writeCache(blob, name) {
    var fs = plugin('Filesystem');
    if (!fs) throw new Error('Filesystem no disponible');
    var res = await fs.writeFile({
      path: 'compartir/' + cleanName(name),
      data: await blobToBase64(blob),
      directory: 'CACHE',
      recursive: true
    });
    return res.uri;
  }

  /* Hoja nativa de compartir con uno o varios archivos. */
  async function shareUris(uris, title) {
    var sh = plugin('Share');
    if (!sh) throw new Error('Share no disponible');
    await sh.share({ title: title || 'Pixora', dialogTitle: 'Compartir', files: uris });
  }

  async function askLegacyPermission(fs) {
    /* Solo hace falta en Android 9 o inferior; en versiones nuevas devuelve "granted". */
    try {
      var p = await fs.checkPermissions();
      if (p && p.publicStorage && p.publicStorage !== 'granted') {
        await fs.requestPermissions();
      }
    } catch (e) { /* si falla, se intenta escribir igualmente */ }
  }

  /* Sustituye a la descarga del navegador: guarda en Documentos/Pixora.
   * Si no se puede escribir ahí, abre la hoja de compartir para que el usuario
   * elija dónde guardarlo (Archivos, Drive, Galería…). */
  N.save = async function (blob, filename) {
    var name = cleanName(filename);
    try {
      var fs = plugin('Filesystem');
      if (!fs) throw new Error('Filesystem no disponible');
      await askLegacyPermission(fs);
      await fs.writeFile({
        path: FOLDER + '/' + name,
        data: await blobToBase64(blob),
        directory: 'DOCUMENTS',
        recursive: true
      });
      toast('Guardado en Documentos/' + FOLDER + ': ' + name);
      return;
    } catch (e) {
      console.warn('[Pixora] No se pudo guardar en Documentos:', e);
    }
    try {
      var uri = await writeCache(blob, name);
      toast('Elige dónde guardar el archivo');
      await shareUris([uri], name);
    } catch (e2) {
      if (!/cancel/i.test(String(e2 && (e2.message || e2)))) {
        console.error('[Pixora] Guardado fallido:', e2);
        toast('No se pudo guardar el archivo');
      }
    }
  };

  /* navigator.share con archivos (la app ya lo usa en "Compartir"). */
  var origCanShare = navigator.canShare ? navigator.canShare.bind(navigator) : null;
  function hasFiles(d) { return !!(d && d.files && d.files.length); }

  function define(name, fn) {
    try {
      Object.defineProperty(navigator, name, { value: fn, configurable: true, writable: true });
    } catch (e) { try { navigator[name] = fn; } catch (e2) {} }
  }

  define('canShare', function (d) {
    if (hasFiles(d)) return !!(plugin('Share') && plugin('Filesystem'));
    return origCanShare ? origCanShare(d) : false;
  });

  define('share', async function (d) {
    if (!hasFiles(d)) {
      var sh = plugin('Share');
      if (!sh) throw new DOMException('Share no disponible', 'NotSupportedError');
      return sh.share({ title: d && d.title, text: d && d.text, url: d && d.url, dialogTitle: 'Compartir' });
    }
    var uris = [];
    for (var i = 0; i < d.files.length; i++) uris.push(await writeCache(d.files[i], d.files[i].name));
    try {
      await shareUris(uris, d.title);
    } catch (e) {
      if (/cancel/i.test(String(e && (e.message || e)))) throw new DOMException('Compartir cancelado', 'AbortError');
      throw e;
    }
  });

  /* Barra de estado: iconos claros sobre la interfaz oscura. */
  try {
    var sb = plugin('SystemBars');
    if (sb && sb.setStyle) sb.setStyle({ style: 'DARK' }).catch(function () {});
  } catch (e) {}
})();
