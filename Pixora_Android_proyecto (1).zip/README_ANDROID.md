# Pixora para Android · guía completa (solo con el móvil)

Pixora es tu editor de Pixelart (HTML + CSS + JavaScript) empaquetado como app Android con **Capacitor 8**.
La compilación se hace en la nube con **GitHub Actions**; no necesitas ordenador.

> **Estado de la verificación.** La versión web se probó en un navegador de pruebas (dibujar, deshacer/rehacer,
> herramientas, importar y exportar PNG, IndexedDB) y el puente nativo se probó contra un Capacitor *simulado*.
> **La compilación Android real todavía no se ha ejecutado** (el entorno donde se preparó no tiene Internet ni Android SDK).
> Hasta que ejecutes el workflow y pruebes el APK en tu móvil, no se puede asegurar que funcione. Mira la sección 11
> si algo falla: casi todos los fallos posibles están previstos ahí.

---

## 0. Qué contiene el proyecto

| Ruta | Para qué sirve |
|---|---|
| `www/index.html` | Tu aplicación original (con 3 cambios mínimos, ver `LISTA_MODIFICACIONES_Y_PENDIENTES.md`) |
| `www/native-bridge.js` | Puente nativo: guardar en el móvil y compartir. En un navegador normal no hace nada |
| `capacitor.config.json` | Configuración de Capacitor: nombre `Pixora`, identificador `com.pixelart.editor` |
| `package.json` | Dependencias (Capacitor 8 + plugins oficiales Filesystem, Share y Keyboard) |
| `scripts/fetch-fonts.mjs` | Descarga las fuentes de Google para que funcionen sin conexión |
| `scripts/patch-android.mjs` | Orientación vertical, teclado, iconos, pantalla de inicio, versión |
| `resources/android/` | Iconos y pantalla de inicio de Pixora (ya generados) |
| `resources/pixora-debug.keystore` | Clave de **depuración** fija (no es secreta; permite actualizar sin desinstalar) |
| `.github/workflows/android.yml` | El flujo de compilación |
| `original/pixelito_texto.html` | **Copia intacta** de tu archivo original |

No hay carpeta `android/` en el proyecto: **el propio flujo la genera** con `npx cap add android` en cada compilación.

---

## 1. Subir el proyecto a GitHub desde Android

Desde Android no se pueden subir carpetas enteras y GitHub no descomprime ZIP. Por eso el flujo está preparado
para **aceptar el ZIP tal cual**: lo descomprime él mismo dentro de la compilación.
Solo tienes que subir **2 cosas**: el ZIP y el archivo `android.yml`.

> **Consejo:** abre github.com en Chrome y activa **⋮ → Sitio para ordenadores**. El menú de subir archivos
> funciona mejor así que en la vista móvil.

### Paso a paso

1. Entra en <https://github.com> e inicia sesión (o crea una cuenta gratuita).
2. Pulsa **+ → New repository**.
   - *Repository name:* `pixora`
   - *Public* (minutos de compilación ilimitados) o *Private* (2000 min/mes gratis; sobra).
   - Marca **Add a README file** (así el repositorio no queda vacío).
   - Pulsa **Create repository**.
3. **Sube el ZIP:** en el repositorio pulsa **Add file → Upload files**, elige `Pixora_Android_proyecto.zip`
   desde *Descargas* y pulsa **Commit changes**.
   - El ZIP debe quedar en la **raíz** del repositorio (no dentro de una carpeta).
4. **Crea el flujo de compilación** (GitHub no permite que un ZIP cree esta carpeta, hay que hacerlo a mano):
   1. Abre en tu móvil el archivo `android.yml` que te entregué junto al ZIP (con un visor de texto)
      y **copia todo su contenido**.
   2. En el repositorio pulsa **Add file → Create new file**.
   3. En el cuadro del nombre escribe exactamente: `.github/workflows/android.yml`
      (al escribir cada `/` GitHub crea la carpeta).
   4. Pega el contenido copiado.
   5. Pulsa **Commit changes… → Commit changes**.

Resultado esperado en la raíz del repositorio: `README.md`, `Pixora_Android_proyecto.zip` y la carpeta `.github`.

### Alternativas (opcionales)

- **Subir los archivos sueltos:** si prefieres tener el código visible en GitHub, descomprime el ZIP en el móvil y
  sube los archivos de uno en uno con *Add file → Upload files* (la carpeta `.github/workflows` hay que crearla como en el paso 4).
  Hay que respetar las rutas exactas de la tabla de arriba. Es más laborioso.
- **Termux (terminal en Android):** `pkg install git unzip`, clona tu repositorio, descomprime el ZIP encima y haz
  `git add . && git commit -m "Pixora" && git push`. Útil si más adelante vas a tocar mucho código.

---

## 2. Ejecutar GitHub Actions

1. En tu repositorio abre la pestaña **Actions**.
2. Si aparece un aviso, pulsa **I understand my workflows, go ahead and enable them**.
3. En la lista de la izquierda (en móvil: botón **All workflows**) elige **Compilar Pixora (Android)**.
4. Pulsa **Run workflow** (a la derecha).
5. En *Qué compilar* deja **apk-debug**.
6. Pulsa el botón verde **Run workflow**.

Después de unos segundos aparece una línea nueva con un círculo amarillo: ya está compilando.

---

## 3. Comprobar si la compilación terminó bien

Tiempo orientativo: **6–12 minutos** la primera vez (después va más rápido por la caché de Gradle).

| Icono | Significado |
|---|---|
| 🟡 círculo amarillo girando | En curso |
| ✅ marca verde | Terminó bien: hay APK |
| ❌ cruz roja | Falló |

Si falla: abre la ejecución → toca el paso marcado con ❌ → se despliega el registro. Mira la sección 11.
Si me pasas el texto de las últimas ~30 líneas del registro, se puede corregir.

---

## 4. Descargar el APK

1. Abre la ejecución terminada (toca la línea con la ✅ en la pestaña *Actions*).
2. Baja hasta el final de la página: sección **Artifacts**.
3. Toca **Pixora-debug-apk**. Se descarga un archivo `.zip` (hay que haber iniciado sesión en GitHub).
4. Descomprímelo con *Archivos de Google* (mantén pulsado → **Extraer**) o con ZArchiver.
   Dentro está **`Pixora-debug.apk`**.

El artefacto se conserva 30 días.

---

## 5. Instalar el APK en tu teléfono

1. Toca `Pixora-debug.apk`.
2. Android pedirá permiso para **instalar apps desconocidas** desde esa aplicación (Archivos/Chrome):
   pulsa **Ajustes**, activa **Permitir desde esta fuente** y vuelve atrás.
3. Pulsa **Instalar**. Si Play Protect avisa de «app no verificada», elige **Instalar de todos modos**
   (es normal en un APK de depuración propio).
4. Abre **Pixora**.

---

## 6. Actualizar la aplicación

1. Cambia lo que necesites (por ejemplo `www/index.html`). Con el método del ZIP: genera un ZIP nuevo con el mismo
   nombre y en GitHub usa **Add file → Upload files** con ese archivo: **reemplaza** al anterior.
2. (Opcional) Sube la versión visible: en `package.json` cambia `"version": "1.0.0"` a `"1.0.1"`.
   El *versionCode* de Android sube solo con cada ejecución.
3. Repite las secciones 2, 4 y 5. Instala el APK nuevo **encima** del anterior.

**No hace falta desinstalar**: todos los APK de depuración llevan la misma firma
(`resources/pixora-debug.keystore`), así que tus dibujos guardados se conservan.

> ⚠️ Los dibujos viven en el almacenamiento interno de la app. **Si desinstalas Pixora, se borran.**
> Antes de desinstalar, exporta tus proyectos (`.pixel.json`).

---

## 7. Generar un AAB de publicación (futuro)

El AAB es el formato que pide Google Play. Necesita **tu propia clave de firma**; yo no la he creado ni inventado contraseñas.

### 7.1 Crear tu clave (una sola vez)

Con Termux: `pkg install openjdk-17` y luego:

```
keytool -genkeypair -v -keystore pixora-release.jks -alias pixora -keyalg RSA -keysize 2048 -validity 10000
```

Anota la contraseña que elijas. **Guarda `pixora-release.jks` en un lugar seguro y haz copia**: si la pierdes no podrás
actualizar la app en Google Play. **No la subas al repositorio.**

Convierte la clave a texto: `base64 -w0 pixora-release.jks` (copia la salida).

### 7.2 Guardar los secretos en GitHub

Repositorio → **Settings → Secrets and variables → Actions → New repository secret**. Crea estos 4:

| Nombre | Valor |
|---|---|
| `ANDROID_KEYSTORE_BASE64` | El texto largo de `base64 -w0` |
| `ANDROID_KEYSTORE_PASSWORD` | La contraseña del almacén de claves |
| `ANDROID_KEY_ALIAS` | `pixora` (o el alias que usaras) |
| `ANDROID_KEY_PASSWORD` | La contraseña de la clave (la misma si no pusiste otra) |

### 7.3 Compilar

**Actions → Compilar Pixora (Android) → Run workflow → Qué compilar: `aab-release`**.
Al terminar, el artefacto **Pixora-release-aab** contiene `Pixora-release.aab`, firmado con tu clave.

Antes de publicar en Google Play: cambia el identificador (sección 8; `com.pixelart.editor` es provisional),
sube la versión, y comprueba los requisitos vigentes de la tienda. El flujo del AAB está preparado pero **no se ha podido probar**.

---

## 8. Cambiar el nombre y el identificador de la app

Todo se cambia en **`capacitor.config.json`** (edítalo en GitHub: abre el archivo → icono del lápiz).
Con el método del ZIP, edita el archivo dentro del ZIP en tu móvil (o descomprime, edita y vuelve a comprimir).

```json
{
  "appId": "com.pixelart.editor",   ← identificador (paquete)
  "appName": "Pixora",              ← nombre que se ve bajo el icono
  ...
}
```

- **Nombre:** cambia `appName`. Opcional: la etiqueta `<title>` de `www/index.html`.
- **Identificador:** cambia `appId` (solo minúsculas, números y puntos, p. ej. `com.tunombre.pixora`).
  Android lo trata como **otra app distinta**: se instala aparte y no hereda los dibujos de la anterior.
- **Icono:** sustituye los PNG de `resources/android/res/mipmap-*/` (nombres `ic_launcher.png`, `ic_launcher_round.png`,
  `ic_launcher_pixora_fg.png`) y las pantallas de `resources/android/splash/`. Si tienes Python, `tools/generate_icons.py`
  los genera todos desde `resources/pixora-icon-512.png`.

---

## 9. Qué cambia en el móvil respecto a la web

| Función | Comportamiento en Android |
|---|---|
| Descargar PNG / GIF / hoja / `.pixel.json` | Se guarda en **Documentos/Pixora** del teléfono. Si no se pudiera escribir ahí, se abre la hoja «Compartir» para elegir destino |
| Compartir | Hoja nativa de compartir de Android |
| Abrir imágenes o proyectos | Selector de archivos del sistema (no pide permisos en Android moderno) |
| Guardado de proyectos / autoguardado | Igual que en la web (IndexedDB dentro de la app) |
| «Conectar carpeta» | No existe en Android WebView; el botón se oculta (la propia app ya lo contempla). Usa Exportar/Abrir archivo |
| Orientación | Vertical fija (la interfaz ya pide el móvil en vertical) |
| Zoom accidental | Desactivado (viewport + `touch-action:none` del lienzo, ya presentes) |
| Sin conexión | Funciona. Las fuentes se descargan al compilar y quedan dentro de la app |

---

## 10. Cómo funciona la compilación (pasos de `android.yml`)

1. Descarga el repositorio · 1b. Descomprime el ZIP si hace falta · 2. Node.js 22 · 3. `npm install` ·
4. Descarga de fuentes (si falla, sigue) · 5. `npx cap add android` · 6. `patch-android.mjs` ·
7. `npx cap sync android` · 8. Java 21 · 9. Android SDK 36 · 10. Gradle ·
11. `./gradlew assembleDebug` (o `bundleRelease`) · 12. Publica el artefacto.

Versiones elegidas (estables a noviembre de 2026): **Capacitor 8** (Node ≥ 22, JDK 21, compileSdk/targetSdk 36, minSdk 24).
Capacitor 9 aún es *prerelease*; no se usa.

---

## 11. Solución de problemas

| Síntoma | Qué hacer |
|---|---|
| ❌ en «1b. Preparar el proyecto» | El ZIP no está en la raíz del repositorio o se subió otro archivo. Vuelve a subirlo (sección 1, paso 3) |
| ❌ en «3. Instalar dependencias» | Algún paquete de npm no existe en esa versión. Copia el error; se fijarán versiones concretas en `package.json` |
| ❌ en «5. Generar el proyecto Android» | Copia el error. Suele ser un fallo temporal de red: vuelve a pulsar *Re-run all jobs* |
| ⚠ en «4. Descargar fuentes» | No es grave: la compilación sigue y la app usará las fuentes desde Internet cuando haya conexión |
| ❌ en «11b. Compilar APK» | Abre el paso y busca la primera línea con `error:` o `FAILED`. Cópiala |
| «No se puede instalar / conflicto con paquete existente» | Tienes instalado un Pixora firmado con otra clave. Exporta tus proyectos, desinstálalo e instala el nuevo |
| La app abre en blanco | Prueba a reinstalar. Si persiste, conecta por USB más adelante o pasa el error y se revisará |
| La barra de estado tapa los botones de arriba | Comunícalo (sección 2 de `LISTA_MODIFICACIONES_Y_PENDIENTES.md`, punto sobre barras del sistema) |
| «Guardado» no aparece en la galería | Los archivos están en **Archivos → Documentos → Pixora**. La galería de fotos no los indexa siempre |

---

## 12. Lo que SÍ y lo que NO se ha comprobado

**Comprobado (navegador de pruebas, Chromium):** la app carga sin errores de JavaScript; el título es «Pixora»;
dibujar, deshacer y rehacer; las 12 herramientas aceptan trazos sin errores; importar una imagen; exportar PNG;
IndexedDB (`pixelito`: `projects` y `kv`); el puente nativo es inofensivo en un navegador normal; con un Capacitor simulado,
«Descargar» escribe en `Documentos/Pixora`, «Compartir» llama a la hoja de compartir y cancelar se interpreta como `AbortError`.
También: sintaxis de los scripts, validez del YAML del workflow, el paso de descompresión del ZIP y el script de parcheo
(contra un proyecto Android simulado, ejecutado dos veces para comprobar que es idempotente).

**NO comprobado:** `npm install` de los plugins, `npx cap add android`, la compilación con Gradle, el APK, el guardado
en `Documentos/Pixora` en un teléfono real, los márgenes bajo las barras del sistema, el teclado virtual, el AAB firmado.
