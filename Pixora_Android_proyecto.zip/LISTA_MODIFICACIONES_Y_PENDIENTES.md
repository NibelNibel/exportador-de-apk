# Pixora · modificaciones realizadas y problemas pendientes

## 1. Modificaciones realizadas

### 1.1 En tu aplicación (`www/index.html`, comparado con `original/pixelito_texto.html`)

Solo **3 cambios**, comprobables con `diff original/pixelito_texto.html www/index.html`:

| # | Cambio | Motivo |
|---|---|---|
| 1 | `<title>Pixelito</title>` → `<title>Pixora</title>` | Nuevo nombre |
| 2 | Añadidas 2 líneas en `<head>`: `<link rel="stylesheet" href="fonts/fonts.css">` y `<script src="native-bridge.js"></script>` | Fuentes locales (sin conexión) y puente nativo |
| 3 | Al inicio de `function download(b,fn)` se añadió: `if(window.PixoraNative&&window.PixoraNative.isNative)return window.PixoraNative.save(b,fn);` | En el WebView de Android las descargas con `<a download>` no funcionan; en navegador normal la función se comporta igual que antes |

No se tocó la lógica del editor, el lienzo, las herramientas, deshacer/rehacer, selección, capas, animación, paletas ni el almacenamiento.
Las claves internas (`indexedDB 'pixelito'`, `localStorage 'pixelito_pal'`) **se conservan** para no romper datos guardados.

### 1.2 Archivos nuevos

- `www/native-bridge.js`: guardar en `Documentos/Pixora`, `navigator.share` con archivos, estilo de la barra de estado. Solo actúa en la app Android.
- `capacitor.config.json`: `appId` `com.pixelart.editor`, `appName` `Pixora`, `webDir` `www`, ajustes de barras del sistema.
- `package.json`: Capacitor 8 (`core`, `cli`, `android`) y plugins oficiales `filesystem`, `share`, `keyboard`.
- `scripts/fetch-fonts.mjs`, `scripts/patch-android.mjs`.
- `resources/android/**`: iconos (legacy, redondo, adaptativo) y pantallas de inicio generados desde tu `pixora.png`.
- `resources/pixora-debug.keystore`: clave de depuración estándar (contraseña pública `android`), **solo para pruebas**.
- `tools/generate_icons.py`: regenera los iconos.
- `.github/workflows/android.yml`: compilación de APK de depuración y AAB firmado (opcional).
- `README_ANDROID.md`, `LISTA_MODIFICACIONES_Y_PENDIENTES.md`, `.gitignore`.
- `original/pixelito_texto.html`: copia intacta.

### 1.3 Ajustes de Android (los aplica `patch-android.mjs` sobre el proyecto generado)

Orientación vertical · `windowSoftInputMode=adjustResize` · permiso de almacenamiento solo hasta Android 9 (`maxSdkVersion=28`) ·
icono y pantalla de inicio de Pixora · `versionName` desde `package.json` y `versionCode` = nº de ejecución · memoria de Gradle 3 GB.

### 1.4 Decisiones técnicas

- **No se incluye `android/` en el ZIP**: no se podía generar aquí sin Internet, y el flujo lo genera solo (así no depende de archivos locales).
- **Capacitor 8** (estable). Capacitor 9 todavía es *prerelease*.
- **Sin AdMob, anuncios ni servicios de pago.** Sin otro framework.
- Se usan solo las APIs web que sí funcionan en WebView (lienzo, IndexedDB, `<input type=file>`, `prompt/confirm`, Pointer Events).
- Plugin `@capacitor-community/media` (guardar en galería) **descartado** de momento para no depender de una API sin verificar.

## 2. Posibles problemas pendientes

1. **No se ha ejecutado ninguna compilación Android real** ni se ha probado el APK en un teléfono. Lo comprobado y lo no comprobado está en la sección 12 del README.
2. **Versiones de npm sin fijar** (`^8.0.0`; no hay `package-lock.json` porque no se pudo generar sin Internet). Si un plugin 8.x nuevo rompe la compilación, hay que fijar versiones exactas.
3. **Plantilla de `cap add android`:** el script de parcheo asume su estructura habitual (manifiesto, `build.gradle`, `splash.png`). Si algo no coincide, avisa en el registro sin romper la compilación, pero el resultado (icono, vertical…) podría no aplicarse.
4. **Guardado en `Documentos/Pixora`:** en Android 10+ depende del almacenamiento por ámbitos; hay que verificarlo en un teléfono real. Si falla, la app abre la hoja de compartir como alternativa. No aparecerá siempre en la galería de fotos.
5. **Barras del sistema (Android 15/16, borde a borde):** la interfaz usa `env(safe-area-inset-*)`; Capacitor 8 lo resuelve con el plugin SystemBars, pero hay que revisar que no se tapen botones arriba o abajo.
6. **Teclado virtual:** `adjustResize` + plugin Keyboard; revisar los cuadros de texto de las hojas inferiores y la herramienta Texto.
7. **Botón «Atrás» de Android:** cierra las hojas (la app usa `history.pushState`), pero en la pantalla principal puede salir de la app. Hay autoguardado, así que se recupera el dibujo.
8. **Pantalla completa** (`requestFullscreen`): puede no estar disponible en WebView; la app muestra un aviso.
9. **«Conectar carpeta»** (`showDirectoryPicker`) no existe en Android: el botón se oculta. No hay sustituto nativo equivalente.
10. **Fuentes sin conexión:** se descargan al compilar. Si ese paso falla, la app las pedirá a Internet. `DotGothic16` añade muchos archivos pequeños (peso del APK).
11. **Datos locales:** al desinstalar la app se borran los proyectos guardados. Recomienda exportar `.pixel.json`.
12. **APK de depuración:** no es válido para Google Play. Para publicar hay que usar el AAB firmado (flujo preparado, **sin probar**) y cambiar `appId`.
13. **Android en tablets/plegables:** al bloquear vertical, la interfaz se ve en columna estrecha.
14. **Icono adaptativo:** el relleno exterior es un degradado prolongado; puede notarse un leve borde si el lanzador anima el icono. Se ajusta con `content` en `tools/generate_icons.py`.
15. **Versiones de las acciones de GitHub** (`checkout@v4`, etc.): pueden mostrar avisos de obsolescencia; actualizar cuando sea necesario.
16. **Método del ZIP:** el repositorio solo contendrá el ZIP (no verás el código como archivos ni habrá historial por archivo). Si más adelante quieres trabajar con Git, descomprime el ZIP en la raíz.
