"""Genera los iconos y la pantalla de inicio de Android a partir de resources/pixora-icon-512.png.
Uso (opcional, el resultado ya está incluido en el repositorio):
    pip install pillow numpy && python tools/generate_icons.py
"""
import os
import numpy as np
from PIL import Image, ImageDraw

SRC = 'resources/pixora-icon-512.png'
OUT = 'resources/android/res'
img = Image.open(SRC).convert('RGBA')

DENS = {'mdpi': 1, 'hdpi': 1.5, 'xhdpi': 2, 'xxhdpi': 3, 'xxxhdpi': 4}

def save(im, folder, name):
    d = os.path.join(OUT, folder)
    os.makedirs(d, exist_ok=True)
    im.save(os.path.join(d, name), optimize=True)

def circle(im):
    m = Image.new('L', im.size, 0)
    ImageDraw.Draw(m).ellipse((0, 0, im.size[0] - 1, im.size[1] - 1), fill=255)
    o = im.copy(); o.putalpha(m); return o

def rounded(im, r):
    m = Image.new('L', im.size, 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, im.size[0] - 1, im.size[1] - 1), r, fill=255)
    o = im.copy(); o.putalpha(m); return o

def padded(px, content):
    """Lienzo px×px con el dibujo escalado en el centro. Nibel: el margen se rellena con el
    mismo degradado del fondo del logo (color de las franjas laterales fila por fila),
    asi no se notan bordes ni manchas alrededor."""
    inner = int(round(px * content))
    small = img.resize((inner, inner), Image.LANCZOS)
    arr = np.array(small).astype(float)
    franja = max(3, inner // 60)
    lados = np.concatenate([arr[:, :franja, :], arr[:, -franja:, :]], axis=1)
    fila = np.median(lados, axis=1)
    # Nibel: se alisa el degradado con una curva suave para que no queden rayitas por los puntitos del fondo
    filas = np.arange(inner)
    fila = np.stack([np.polyval(np.polyfit(filas, fila[:, c], 3), filas) for c in range(fila.shape[1])], axis=1).clip(0, 255)
    pad = (px - inner) // 2
    colores = np.concatenate([np.repeat(fila[:1], pad, 0), fila, np.repeat(fila[-1:], px - inner - pad, 0)], axis=0)
    ext = Image.fromarray(np.repeat(colores[:, None, :], px, axis=1).astype(np.uint8), 'RGBA')
    ext.alpha_composite(small, (pad, pad))
    return ext

def adaptive_fg(px, content=0.56):
    # El dibujo cabe en el círculo de 66dp de la zona segura de los iconos adaptativos.
    return padded(px, content)

for d, f in DENS.items():
    legacy = img.resize((int(48 * f), int(48 * f)), Image.LANCZOS)
    save(legacy, 'mipmap-' + d, 'ic_launcher.png')
    save(circle(padded(int(48 * f), 0.74)), 'mipmap-' + d, 'ic_launcher_round.png')
    save(adaptive_fg(int(108 * f)), 'mipmap-' + d, 'ic_launcher_pixora_fg.png')

# Pantalla de inicio (fondo oscuro de la app + icono)
BG = (4, 6, 13, 255)
for name, size in (('splash_port.png', (1080, 1920)), ('splash_land.png', (1920, 1080))):
    can = Image.new('RGBA', size, BG)
    ic = rounded(img.resize((400, 400), Image.LANCZOS), 72)
    can.alpha_composite(ic, ((size[0] - 400) // 2, (size[1] - 400) // 2))
    d = os.path.join('resources/android', 'splash')
    os.makedirs(d, exist_ok=True)
    can.convert('RGB').save(os.path.join(d, name), optimize=True)

# Icono de ficha de tienda (para una futura publicación)
img.save('resources/playstore-icon-512.png')
print('OK')
